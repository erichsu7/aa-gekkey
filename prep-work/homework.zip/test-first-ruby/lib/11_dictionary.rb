class Dictionary
	attr_accessor :entries
	def initialize
		@entries = {}
	end
	def add(args={})
		if args.class == String
			@entries[args] = nil
		elsif args.class == Hash
			@entries.merge!(args)
		end
	end
	def keywords
		@entries.keys.sort
	end
	def include?(x)
		@entries.has_key?(x)
	end
	def find(x)
		found = {}
		self.keywords.each do |i|
			found[i] = @entries[i] if /#{x}.*/.match(i)
		end
		return found
	end
	def printable
		s = nil
		self.keywords.each do |k|
			v = @entries[k]
			s = (s ? s+"\n" : "") + "[#{k}] \"#{v}\""
		end
		return s
	end
end