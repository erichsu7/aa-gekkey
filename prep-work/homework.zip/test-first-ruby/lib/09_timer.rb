class Timer
	attr_accessor :seconds
	def initialize
		@seconds = 0
	end
	def time_string
		"%02i:%02i:%02i" % [(@seconds/3600)%24, (@seconds/60)%60, @seconds%60]
	end
end