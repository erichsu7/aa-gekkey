class Array
	def sum
		self.inject {|y, i| y += i} || 0
	end
	def square
		self.collect {|i| i * i}
	end
	def square!
		self.collect! {|i| i * i}
	end
end