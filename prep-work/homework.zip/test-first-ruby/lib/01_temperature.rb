def ftoc x # fahrenheit to celcius
	(x - 32) * 5/9.0
end

def ctof x
	(x * 9/5.0) + 32
end