class RPNCalculator < Array
	def _math(arg)
		raise "calculator is empty" if self.size == 0
		case arg
		when 'add'
			return self.pop + self.pop
		when 'sub'
			return -self.pop + self.pop
		when 'div'
			return 1.0/self.pop * self.pop
		when 'mul'
			return self.pop * self.pop
		end
	end
	def plus
		self.push(self._math'add')
	end
	def minus
		self.push(self._math'sub')
	end
	def divide
		self.push(self._math'div')
	end
	def times
		self.push(self._math'mul')
	end
	def value
		self[-1]
	end
	def tokens(x)
		y = []
		x.split(' ').each do |i|
			case i
			when /[0-9]/
				z = i.to_i
			when '+', '*', '-', '/'
				z = i.intern
			end
			y.push(z)
		end
		return y
	end
	def evaluate(x)
		x.split(' ').each do |i|
			case i
			when /[0-9]/
				self.push(i.to_i)
			when '+'
				self.plus
			when '*'
				self.times
			when '-'
				self.minus
			when '/'
				self.divide
			end
		end
		return self.value
		ensure self.clear
	end
end
