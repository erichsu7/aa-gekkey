def reverser
	x = yield
	s = ''
	x.split(' ').each do |y|
		s += y.reverse + ' '
	end
	return s[0..-2]
end

def adder(y=1)
	return yield + y
end

def repeater(x=1)
	x.times do
		yield
	end
end

n = 0
repeater(10) do
	n += 1
end
puts n