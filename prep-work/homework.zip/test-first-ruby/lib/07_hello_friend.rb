class Friend
	def greeting(name=nil)
		return "Hello#{name ? ', '+name : ''}!"
	end
end
