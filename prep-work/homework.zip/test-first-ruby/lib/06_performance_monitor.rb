require "time"
def measure(n=1)
	t_start = Time.now.to_f
	n.times do
		yield
	end
	return (Time.now.to_f - t_start) / n
end
