IGNORE = ['a', 'an', 'the', 'and', 'but', 'or', 'for', 'nor', 'on', 'in', 'at', 'to', 'from', 'by', 'over', 'of']
def echo(x)
	return x
end 
def shout(x)
	return x.upcase
end
def repeat(x, y=2)
	return ((x+' ')*y).strip
end
def start_of_word(x, y=1)
	return x[0..y-1]
end
def first_word(x)
	return x.split(' ')[0]
end
def titleize(x)
	y = first_word(x).capitalize
	x.split(' ')[1..-1].each {|i| y += ' '+(IGNORE.include?(i) ? i : i.capitalize)}
	return y
end