C = 5.0/9.0
class Temperature
	def self.ctof(x)
		x / C + 32
	end
	def self.ftoc(x)
		(x - 32) * C
	end
	def self.from_celsius(x)
		self.new(:c => x)
	end
	def self.from_fahrenheit(x)
		self.new(:f => x)
	end

	def initialize(args={})
		@celsius = args.include? :c
		@temp = args[:c] || args[:f]
	end
	def in_celsius
		return @temp if @celsius
		self.class.ftoc(@temp)
	end
	def in_fahrenheit
		return @temp unless @celsius
		self.class.ctof(@temp)
	end
end

class Celsius < Temperature
	def initialize(x)
		@celsius = true
		@temp = x
	end
end

class Fahrenheit < Temperature
	def initialize(x)
		@celsius = false
		@temp = x
	end
end