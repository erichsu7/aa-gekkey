VOWELS = ['a', 'e', 'i', 'o', 'u']
PUNCTUATION = ['.', ',', ';', ':']

def translate(x)
	s = ''
	x.split(' ').each do |y|
		if VOWELS.include? y[0].downcase
			if PUNCTUATION.include? y[-1] 
				p = y[-1]
				y = y[0..-2]
			end
			s += y + 'ay' + (p ? p : '') + ' '
			next
		end
		(0..y.length-1).each do |i|
			if VOWELS.include? y[i]
				if y[i] == 'u' && y[i-1] == 'q' then next end
				if PUNCTUATION.include? y[-1] 
					p = y[-1]
					y = y[0..-2]
				end
				z = y[i..-1] + y[0..i-1] + 'ay' + (p ? p : '') + ' '
				if /[A-Z]/.match(y[0]) then z.capitalize! end
				s += z
				break
			end
		end
	end
	return s[0..-2] # to get rid of the last space
end