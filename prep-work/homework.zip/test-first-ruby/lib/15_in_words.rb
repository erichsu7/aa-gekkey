WORD_MAP = {1 => "one", 
			2 => "two",
			3 => "three",
			4 => "four",
			5 => "five",
			6 => "six",
			7 => "seven",
			8 => "eight",
			9 => "nine",
			10 => "ten",
			11 => "eleven",
			12 => "twelve",
			13 => "thirteen",
			14 => "fourteen",
			15 => "fifteen",
			16 => "sixteen",
			17 => "seventeen",
			18 => "eighteen",
			19 => "nineteen",
			20 => "twenty",
			30 => "thirty",
			40 => "forty",
			50 => "fifty",
			60 => "sixty",
			70 => "seventy",
			80 => "eighty",
			90 => "ninety",
			100 => "hundred",
			1000 => "thousand",
			1_000_000 => "million",
			1_000_000_000 => "billion",
			1_000_000_000_000 => "trillion"
		   }
ORDER = WORD_MAP.keys.sort_by {|k, v| -k}

class Fixnum
	def in_words
		return "zero" if self == 0
		x = self
		s = ""
		ORDER.each do |i|
			next if x < i
			if x >= 100
				s += ' ' + (x / i).in_words + ' ' + WORD_MAP[i]
				x -= x / i * i
			else
				s += ' ' + WORD_MAP[i]
				x -= i
			end
		end
		return s[1..-1]
	end
end