require_relative '03_simon_says'
class Book
	def title=(title)
		@title = titleize(title)
	end
	def title
		return @title
	end
end