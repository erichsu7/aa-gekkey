def add(x, y)
	x + y
end
def subtract(x, y)
	x - y
end
def sum(x)
	y = 0
	x.each {|i| y += i}
	return y
end
def multiply(x, y, *z)
	s = x * y
	z.each {|i| s *= i}
	return s
end
def power(x, y)
	x ** y
end
def factorial(x)
	y = 1
	while x > 1
		y *= x
		x -= 1
	end
	return y
end
