class XmlDocument
	def initialize(indent=false)
		@indent = indent
		@depth = 0
	end
	def send(tag_name, args={}, &block)
		@depth += 1
		s = (@indent ? "  "*(@depth-1) : "") + "<" + tag_name
		x = block_given? ? yield : nil
		args.each do |k, v|
			k = k.to_s if k.class == Symbol
			s += " #{k}='#{v}'"
		end
		s += (x ? '' : '/') + ">" + (@indent ? "\n" : "")
		return s unless x
		s += x
		@depth -= 1
		s + (@indent ? "  "*(@depth-1) : "") + "</#{tag_name}>" + (@indent ? "\n" : "")
	end
	def hello(args={}, &block)
		self.send("hello", args, &block)
	end
	def goodbye(args={}, &block)
		self.send("goodbye", args, &block)
	end
	def come_back(args={}, &block)
		self.send("come_back", args, &block)
	end
	def ok_fine(args={}, &block)
		self.send("ok_fine", args, &block)
	end
end